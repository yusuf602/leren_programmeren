from challenges.solutions import *

challenges = { 
    1 : {
        'start': ',,l', 
        'solution': 'l', 
        'name': 'box to start', 
        'levels':'2:10,3:10/6', 
        'info':'move box to spot 0'
    }
}